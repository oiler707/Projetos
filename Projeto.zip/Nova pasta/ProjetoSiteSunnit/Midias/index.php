<?php

include('../ConfiguradorArquivo.php');


$TempControlador = new ControladorSunnit();
$TempControlador->Midias();



?>