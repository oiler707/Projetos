<?php

Class ControladorSunnit
{
	function __construct(){
		

		
	}

	function Integrador(){
		$CorpoRota=file_get_contents("PastaVisao/Apresentacao/Integrador.html");
		$Rota="";
		include ("PastaVisao/Principal.html");
	}
	function Clientes(){
		$CorpoRota=file_get_contents("../PastaVisao/Apresentacao/Cliente.html");
		$Rota="";
		include ("../PastaVisao/Principal.html");
	}
	function Bancos(){
		$CorpoRota=file_get_contents("../PastaVisao/Apresentacao/Bancos.html");
		$Rota="";
		include ("../PastaVisao/Principal.html");
	}
	function Distribuidor(){
		$CorpoRota=file_get_contents("../PastaVisao/Apresentacao/Distribuidor.html");
		$Rota="";
		include ("../PastaVisao/Principal.html");
	}
		function QuemSomos(){
		$CorpoRota=file_get_contents("../PastaVisao/Apresentacao/QuemSomos.html");
		$Rota="";
		include ("../PastaVisao/Principal.html");
	}
		function Midias(){
		$CorpoRota=file_get_contents("../PastaVisao/Apresentacao/Midias.html");
		$Rota="";
		include ("../PastaVisao/Principal.html");
	}
		function Inicial(){
		$CorpoRota=file_get_contents("../PastaVisao/Apresentacao/Inicial.html");
		$Rota="";
		include ("../PastaVisao/Principal.html");
	}
			function Login(){
		$CorpoRota=file_get_contents("../PastaVisao/Apresentacao/Login.html");
		$Rota="";
		include ("../PastaVisao/Principal.html");
	}

}	