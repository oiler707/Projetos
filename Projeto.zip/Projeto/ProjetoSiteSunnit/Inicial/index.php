<?php

include('../ConfiguradorArquivo.php');


$TempControlador = new ControladorSunnit();
$TempControlador->Inicial();



?>