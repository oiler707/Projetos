<?php

Class ControladorItalia
{
	function __construct(){
		

		$this->ControladorItalia();
	}

	function ControladorItalia(){
		

		$ModeloItalia = new ModeloItalia();
			

		echo(json_encode(['RetornoItalia'=>$ModeloItalia->BuscarTodos()]));

	}




}
?>