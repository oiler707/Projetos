<?php

Class ControladorGoogle
{
	function __construct(){
		

		$this->ControladorGoogle();
	}

	function ControladorGoogle(){
		

		$ModeloPrevisao = new ModeloPrevisao();
			

		echo(json_encode(['RetornoGoogle'=>$ModeloPrevisao->BuscarTodos()]));

	}




}
?>