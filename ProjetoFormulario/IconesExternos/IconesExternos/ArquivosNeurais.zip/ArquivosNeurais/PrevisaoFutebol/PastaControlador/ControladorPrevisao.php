<?php

Class ControladorPrevisao
{
	function __construct(){
		

		$this->ControladorPrevisao();
	}

	function ControladorPrevisao(){

		include ("PastaVisao/VisaoPrevisao.html");
	}




}
?>