<?php

Class ControladorRegressao
{
	function __construct(){
		

		$this->ControladorRegressao();
	}

	function ControladorRegressao(){
		

		$ModeloRegressao = new ModeloRegressao();
			

		echo(json_encode(['RetornoRegressao'=>$ModeloRegressao->BuscarTodos()]));

	}




}
?>