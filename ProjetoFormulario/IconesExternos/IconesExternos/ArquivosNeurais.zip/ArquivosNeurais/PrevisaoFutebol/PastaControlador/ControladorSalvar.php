<?php

Class ControladorSalvar
{
	function __construct(){
		

		
	}

	function SalvarGoogle(){

		header("Content-Type: text/html; charset=ISO-8859-1", true);
		
		if(isset($_POST['ObjetoSistema'])){
			

			$ModeloPrevisao = new ModeloPrevisao();

			$RetornoSalvar = $ModeloPrevisao->SalvarPrevisao($_POST['ObjetoSistema']);
			
		}
		
	}
	function SalvarRegressao(){

		header("Content-Type: text/html; charset=ISO-8859-1", true);
		
		if(isset($_POST['ObjetoSistema'])){
			

			$ModeloRegressao = new ModeloRegressao();

			$RetornoSalvar = $ModeloRegressao->SalvarRegressao($_POST['ObjetoSistema']);
			
		}
		
	}

	function SalvarPrevisao(){

		header("Content-Type: text/html; charset=ISO-8859-1", true);
		
		if(isset($_POST['ObjetoSistema'])){
			

			$ModeloItalia = new ModeloItalia();

			$RetornoSalvar = $ModeloItalia->SalvarPrevisao($_POST['ObjetoSistema']);
			
		}
		
	}





}
?>