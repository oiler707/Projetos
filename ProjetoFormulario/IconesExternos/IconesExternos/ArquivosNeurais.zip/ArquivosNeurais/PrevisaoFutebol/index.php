<?php

include('ConfiguradorArquivo.php');


new ControladorPrevisao()




?>