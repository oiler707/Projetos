<?php

include('../ConfiguradorArquivo.php');



new ControladorItalia()



?>