<?php

include('../ConfiguradorArquivo.php');



new ControladorRegressao()



?>