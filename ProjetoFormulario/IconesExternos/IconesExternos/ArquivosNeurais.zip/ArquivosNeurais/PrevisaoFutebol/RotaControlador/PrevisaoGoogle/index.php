<?php

include('../ConfiguradorArquivo.php');



new ControladorGoogle()



?>