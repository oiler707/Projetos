<?php

include('../ConfiguradorArquivo.php');


	$ControladorSalvar = new ControladorSalvar();

	$ControladorSalvar->SalvarRegressao();

	




?>