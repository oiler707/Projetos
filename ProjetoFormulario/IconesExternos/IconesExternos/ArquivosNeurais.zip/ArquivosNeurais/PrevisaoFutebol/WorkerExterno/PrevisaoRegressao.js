self.onmessage = event => { 
	//text+=event.data.timeOuts+"<br>";

	var xhttp = new XMLHttpRequest();

	xhttp.open("POST", "/PrevisaoFutebol/RotaControlador/PrevisaoRegressao", true);
    xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    
    var ParametroAcao

    xhttp.send(ParametroAcao);

    var RetornoRegressao=''
    
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {


        	   TemporarioRetorno= JSON.parse(xhttp.response)['RetornoRegressao']
               RetornoRegressao+="<div Class='TextoBranco'>"
               RetornoRegressao+='<table>'
               RetornoRegressao+='<thead>'

                 ObjetoTr={"RegrTime1":"Regressão 1",
                 "RegrTime2": "Regressão 2",
                 "Tempo":"O tempo será 20 min."
                 }

               RetornoRegressao = IncluirTr(ObjetoTr,RetornoRegressao)

               RetornoRegressao+='</thead>'
               RetornoRegressao+='<tbody>'

               TemporarioRetorno.forEach(function(e){
                	RetornoRegressao = IncluirTr(e,RetornoRegressao)


               })

               RetornoRegressao+='</tbody>'

               RetornoRegressao+='<tfoot>'
              
               RetornoRegressao+='<tr>'
               RetornoRegressao+='<td colspan="2">'
               RetornoRegressao+='<button onclick="InserirRegressao(this)">Inserir Regressão</button>'
               RetornoRegressao+='</td>'
               RetornoRegressao+='</tr>'
               
               RetornoRegressao+='</tfoot>'

               RetornoRegressao+='</table>'

                  
               RetornoRegressao+="</div>"




               
        	self.postMessage({RetornoRegressao:RetornoRegressao})

        }

	}
}

function IncluirTr(ObjetoTr,RetornoRegressao){
                console.log(ObjetoTr)
               RetornoRegressao+="<tr>"
               RetornoRegressao = IncluirTd(ObjetoTr["RegrTime1"],RetornoRegressao)
               RetornoRegressao = IncluirTd(ObjetoTr["RegrTime2"],RetornoRegressao)
               RetornoRegressao = IncluirTd(ObjetoTr["Tempo"],RetornoRegressao)
               RetornoRegressao+='</tr>'
               return RetornoRegressao
}

function IncluirTd(TextoTd,RetornoRegressao){
  if(TextoTd){
    RetornoRegressao+='<td>'+TextoTd+'</td>'
  }
  return RetornoRegressao
}