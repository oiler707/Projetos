self.onmessage = event => { 

	var xhttp = new XMLHttpRequest();

	xhttp.open("POST", "/PrevisaoFutebol/RotaControlador/SalvarRegressao/index.php", true);
	xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

	var ParametroAcao

	ObjetoSistema={"RegressaoTime1":event.data.RegressaoTime1,
	     "RegressaoTime2": event.data.RegressaoTime2,
	     }

	
	
	ParametroAcao="ObjetoSistema="+JSON.stringify(ObjetoSistema);

	xhttp.send(ParametroAcao);

	xhttp.onreadystatechange = function () {
	    if (this.readyState == 4 && this.status == 200) {
	    	console.log(xhttp.response)
			self.postMessage({"RetornoSistema":xhttp.response})				
				
		}
	}
}