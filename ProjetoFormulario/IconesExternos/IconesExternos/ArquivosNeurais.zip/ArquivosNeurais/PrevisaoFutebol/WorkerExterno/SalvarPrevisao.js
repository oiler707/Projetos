self.onmessage = event => { 
	
	var xhttp = new XMLHttpRequest();

	xhttp.open("POST", "/PrevisaoFutebol/RotaControlador/SalvarPrevisao/index.php", true);
	xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

	var ParametroAcao

	ObjetoSistema={
		 "ValorTime1":parseFloat(event.data.ValorTime1).toFixed(4),
	     "ValorTime2": parseFloat(event.data.ValorTime2).toFixed(4),
	     "Tempo": event.data.Tempo,

	     }


	ParametroAcao="ObjetoSistema="+JSON.stringify(ObjetoSistema);

	xhttp.send(ParametroAcao);

	xhttp.onreadystatechange = function () {

	    if (this.readyState == 4 && this.status == 200) {
	    	

			self.postMessage({"RetornoPrevisao":xhttp.response})				
				
		}
	}
}