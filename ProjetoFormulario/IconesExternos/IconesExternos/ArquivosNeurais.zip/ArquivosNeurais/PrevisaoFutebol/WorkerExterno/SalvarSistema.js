self.onmessage = event => { 

	var xhttp = new XMLHttpRequest();

	xhttp.open("POST", "/PrevisaoFutebol/RotaControlador/SalvarSistema/index.php", true);
	xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

	var ParametroAcao

	ObjetoSistema={"[%G]/[V.Alg.]":event.data.ValorCalculo[0],
	     "Exp([%G]/[V.Alg.])": event.data.ValorCalculo[1],
	     "([%G]+[V.Alg.])/([%G]-[V.Alg.])": event.data.ValorCalculo[2],
	     "1/([%G]+[V.Alg.])": event.data.ValorCalculo[3],
	     "[%G]/[V.Alg.] : 2":event.data.ValorCalculo[4],
	     "Exp([%G]/[V.Alg.]) : 2": event.data.ValorCalculo[5],
	     "([%G]+[V.Alg.])/([%G]-[V.Alg.]) : 2": event.data.ValorCalculo[6],
	     "1/([%G]+[V.Alg.]) : 2": event.data.ValorCalculo[7],
	     "Time 1 [%G]": event.data.ValorVerdadeiro[0],
	     "Time 1 [V.Alg]": event.data.ValorVerdadeiro[1],
	     "Time 2 [%G]": event.data.ValorVerdadeiro[2],
	     "Time 2 [V.Alg]": event.data.ValorVerdadeiro[3],
	     "Ref. 1": event.data.ValorReferencia[0],
	     "Ref. 2": event.data.ValorReferencia[1],
	     "Ref. 3": event.data.ValorReferencia[2],
	     "Ref. 4": event.data.ValorReferencia[3],
	     "Tempo": event.data.TempoFinal}

	ParametroAcao="ObjetoSistema="+JSON.stringify(ObjetoSistema);

	xhttp.send(ParametroAcao);

	xhttp.onreadystatechange = function () {
	    if (this.readyState == 4 && this.status == 200) {
			self.postMessage({"RetornoSistema":xhttp.response})				
				
		}
	}
}