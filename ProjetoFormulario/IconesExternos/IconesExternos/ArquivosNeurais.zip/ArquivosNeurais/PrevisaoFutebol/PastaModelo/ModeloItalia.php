<?php 

class ModeloItalia{

	public function BuscarTodos(){
		$conn = new mysqli('localhost', 'root', '', 'previsaofutebol');
		
		header("Content-Type: text/html; charset=ISO-8859-1", true);
		$sql="SELECT * FROM previsaoitalia";
		$data=[];
		if ($resultSet = $conn->query($sql))
			{
			$i = 0;
			while ($aux = $resultSet->fetch_assoc())
				{
				$data[$i] = $aux;
				$i++;
				};
			}

		return $data;

	}


	public function SalvarPrevisao($ObjetoSistema){

		$conn = new mysqli('localhost', 'root', '', 'previsaofutebol');
		
		$TempObjeto=json_decode($ObjetoSistema,true);

		$Temp1 = $TempObjeto['ValorTime1'];
	
		$Temp2 = $TempObjeto['ValorTime2'];

		$Temp3 = $TempObjeto['Tempo'];

		if($Temp1!="NaN" && $Temp2 !="NaN"){
		
			$sql = "INSERT INTO `previsaoitalia`(`ValorTime1`, `ValorTime2`, `Tempo`) VALUES ($Temp1,$Temp2,$Temp3)";
			

			header("Content-Type: text/html; charset=ISO-8859-1", true);

			echo($conn->query($sql));
			
		}
		else{
			echo(false);
			
		}



	}

}

?>