<?php 

class ModeloRegressao{

	public function BuscarTodos(){
			$conn = new mysqli('localhost', 'root', '', 'previsaofutebol');
			
			header("Content-Type: text/html; charset=ISO-8859-1", true);
			$sql="SELECT * FROM previsaoregressao";
			$data=[];
			if ($resultSet = $conn->query($sql))
				{
				$i = 0;
				while ($aux = $resultSet->fetch_assoc())
					{
					$data[$i] = $aux;
					$i++;
					};
				}

			return $data;

		}



	public function SalvarRegressao($ObjetoSistema){
		
		$conn = new mysqli('localhost', 'root', '', 'previsaofutebol');
		
		$TempObjeto=json_decode($ObjetoSistema,true);

		$Temp1 = $TempObjeto['RegressaoTime1'];
	
		$Temp2 = $TempObjeto['RegressaoTime2'];


		if($Temp1!="NaN" && $Temp2 !="NaN"){
		
			$sql = "INSERT INTO `previsaoregressao`(`RegrTime1`, `RegrTime2`) VALUES ($Temp1,$Temp2)";
			
			header("Content-Type: text/html; charset=ISO-8859-1", true);

			echo($conn->query($sql));
			
		}
		else{
			echo(false);
			
		}
	}


}


?>