
#include <confuse.h>
#include <bits/stdc++.h>
#include <arpa/inet.h>
#include <unistd.h>

using namespace std;
int main(int argc, char* argv[])
{
    int socket_desc, client_sock, c, read_size;
    struct sockaddr_in server, client;

    //sudo apt instal g++
    //sudo apt instal make
    // CONFIGURAÇAO
    // DOWNLOAD http://download.savannah.gnu.org/releases/confuse/confuse-2.7.zip
    //  COMANDO ./configure
    // make
    // sudo su -c 'make install'
    // incluir cd src/ su -c 'cp confuse.h /usr/include'
    int porta;
    int tam_arquivo;
    cfg_t* cfg;
    cfg_opt_t opts[] = {
        CFG_SIMPLE_INT("size", &tam_arquivo),
        CFG_SIMPLE_INT("port", &porta),

        CFG_END()
    };
    cfg = cfg_init(opts, 0);
    cfg_parse(cfg, "conf.conf");
    cfg_free(cfg);

    // CONFIGURAÇAO

    // PRIMEIRA PARTE CRIAR SOCKET
    //Create socket
    socket_desc = socket(AF_INET, SOCK_STREAM, 0);
    if (socket_desc == -1) {
        printf("Could not create socket");
    }
    puts("Socket created");

    //Prepare the sockaddr_in structure
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = INADDR_ANY;
    server.sin_port = htons(porta);

    //SEGUNDA PARTE BIND SOCKET
    //Bind
    if (bind(socket_desc, (struct sockaddr*)&server, sizeof(server)) < 0) {
        //print the error message
        perror("bind failed. Error");
        return 1;
    }
    puts("bind done");
    // TERCEIRA PARTE LISTEN SOCKET
    //Listen
    listen(socket_desc, 3);

    // 4 PARTE ACEITA CONEXAO
    //Accept and incoming connection
    puts("Waiting for incoming connections...");
    c = sizeof(struct sockaddr_in);

    //accept connection from an incoming client
    client_sock = accept(socket_desc, (struct sockaddr*)&client, (socklen_t*)&c);
    if (client_sock < 0) {
        perror("accept failed");
        return 1;
    }
    puts("Connection accepted");

    //Receive a message from client
    string getData;
    char client_message[2048];
    string verific;
    int j = 0;
    int tamanho = 0;
    char process[5] = { 65, 65, 65, 65, 65 };
    FILE* fp;
    FILE* fo;
    int processos_contador = 0;

    std::ifstream ifs("data.txt");
    if (ifs) {

        fo = fopen("data.txt", "r");
        fscanf(fo, "%d", &processos_contador);
        fscanf(fo, "%d", &tamanho);

        printf("%d%d", processos_contador, tamanho);

        fclose(fo);
    }

    ifs.close();

    string namefile;
    char name[0x100];
    string str;
    while (1) {

        // 5 PARTE RECEBER MENSAGEM
        if ((recv(client_sock, client_message, sizeof(client_message), 0)) > 0) {

            getData.append(client_message, strlen(client_message));

            verific = client_message;

            //7 PARTE FINALIZAR
            if (strcmp("fim", client_message) == 0) {
                fclose(fp);
                fo = fopen("data.txt", "w");
                fprintf(fo, "%d %d", processos_contador, tamanho);
                fclose(fo);
                cout << endl<<"############### PROCESSO FINALIZADO"<< endl;
                close(socket_desc);
                return 0;
            }
            int valor = (processos_contador + 65) / 90;
            int resto = (processos_contador + 65) % 90;
            for (int aux = 0; aux < valor; aux++) {
                process[aux] = 90;
            }
            process[valor] = resto;

            snprintf(name, sizeof(name), "Arquivos/%c%c%c%c%c.txt",
                process[0], process[1], process[2], process[3], process[4]);

            fp = fopen(name, "a+");
            int aux2 = tamanho;
            for (int k = tamanho; k < tamanho + strlen(client_message); k++) {
                if (aux2 == tam_arquivo) {
                    aux2 = 0;
                    
                    processos_contador++;
                    fclose(fp);

                    int valor = (processos_contador + 65) / 90;
                    int resto = (processos_contador + 65) % 90;
                    for (int aux = 0; aux < valor; aux++) {
                        process[aux] = 90;
                    }
                    process[valor] = resto;

                    snprintf(name, sizeof(name), "Arquivos/%c%c%c%c%c.txt",
                        process[0], process[1], process[2], process[3], process[4]);
                    fp = fopen(name, "a");
                }

                fprintf(fp, "%c", getData[k]);

                aux2++;
            }
            tamanho = aux2;
            fclose(fp);

            //6 PARTE ENVAIR MENSAGEM
            send(client_sock, "#", 10, 0);
        }
    }
    if (read_size == 0) {
        //puts("Client disconnected");
        // fflush(stdout);
    }
    else if (read_size == -1) {
        perror("recv failed");
    }

    return 0;
}
